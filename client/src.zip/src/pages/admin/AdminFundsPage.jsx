// src/pages/AdminFundsPage.js
import React, { useState } from "react";
import axios from "axios";

const AdminFundsPage = () => {
  const [projectName, setProjectName] = useState("");
  const [allocatedFunds, setAllocatedFunds] = useState("");
  const [document, setDocument] = useState(null);
  const [message, setMessage] = useState("");

  const handleFileChange = (e) => {
    setDocument(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("projectName", projectName);
    formData.append("allocatedFunds", allocatedFunds);
    if (document) {
      formData.append("document", document);
    }

    try {
      const response = await axios.post("http://localhost:5000/api/funds", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
      setMessage("Project added successfully!");
      setProjectName("");
      setAllocatedFunds("");
      setDocument(null);
    } catch (error) {
      setMessage("Failed to add project. Please try again.");
    }
  };

  return (
    <div>
      <h2>Add New Project Fund</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Project Name:</label>
          <input
            type="text"
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Allocated Funds:</label>
          <input
            type="text"
            value={allocatedFunds}
            onChange={(e) => setAllocatedFunds(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Upload Document (optional):</label>
          <input type="file" onChange={handleFileChange} />
        </div>
        <button type="submit">Add Project</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
};

export default AdminFundsPage;