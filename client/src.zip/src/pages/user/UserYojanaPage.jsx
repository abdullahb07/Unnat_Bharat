// src/pages/UserYojanaPage.js
import React, { useEffect, useState } from "react";
import axios from "axios";

const UserYojanaPage = () => {
  const [yojanas, setYojanas] = useState([]);

  useEffect(() => {
    const fetchYojanas = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/yojanas");
        setYojanas(response.data);
      } catch (error) {
        console.error("Failed to fetch Yojanas:", error);
      }
    };

    fetchYojanas();
  }, []);

  return (
    <div>
      <h2>Available Yojanas</h2>
      <ul>
        {yojanas.map((yojana) => (
          <li key={yojana._id}>
            <a href={yojana.link} target="_blank" rel="noopener noreferrer">
              {yojana.name}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UserYojanaPage;