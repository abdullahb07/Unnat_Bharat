import React from 'react'

function complaint() {
    return (
        <><div className="complaint">
            <h1>COMPLAINT</h1>
        </div><div className="com-container">
                <button className="button">Trap Complaints</button>
                <button className="button">Disproportionate Assets Complaints</button>
                <button className="button">Misuse of Power</button>
            </div></>
    )
}

export default complaint