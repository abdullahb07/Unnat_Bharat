import React, { useEffect, useState } from "react";
import axios from "axios";

const UserFundsPage = () => {
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/funds");
        setProjects(response.data);
      } catch (error) {
        console.error("Failed to fetch projects:", error);
      }
    };

    fetchProjects();
  }, []);

  return (
    <div>
      <h2>Funded Projects</h2>
      <ul>
        {projects.map((project) => (
          <li key={project._id}>
            <h3>{project.projectName}</h3>
            <p>Allocated Funds: ₹{project.allocatedFunds}</p>
            <p>Status: {project.document ? "In Progress" : "Pending"}</p>
            {project.document && (
              <div>
                <a
                  href={`http://localhost:5000/uploads/${project.document}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  View Document
                </a>
                <a
                  href={`http://localhost:5000/uploads/${project.document}`}
                  download
                >
                  Download Document
                </a>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UserFundsPage;
