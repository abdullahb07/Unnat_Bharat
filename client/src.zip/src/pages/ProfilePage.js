import React from "react";

const ProfilePage = () => {
  // Placeholder user information
  const user = {
    name: "John Doe",
    phoneNumber: "123-456-7890",
    aadharNumber: "1234-5678-9012",
  };

  return (
    <div>
      <h1>Profile</h1>
      <p>Name: {user.name}</p>
      <p>Phone Number: {user.phoneNumber}</p>
      <p>Aadhar Number: {user.aadharNumber}</p>
      {/* Display user's complaint history here */}
    </div>
  );
};

export default ProfilePage;
