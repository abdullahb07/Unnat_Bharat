import React from "react";

const Helpline = () => (
  <div>
    <p>For further assistance, please call our helpline at 1800-123-4567.</p>
  </div>
);

export default Helpline;
